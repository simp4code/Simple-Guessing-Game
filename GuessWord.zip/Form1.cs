﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GuessWord
{
    public partial class Form1 : Form
    {
        string[] wordList = { "house","dog","throw","fish","lift","sequence","denial","inevitable","tangent","courtyard" };
        string guessWord = string.Empty;
        Random number = new Random();
        StringBuilder arrayWordBuild = new StringBuilder();
        public Form1()
        {
            InitializeComponent();
            guessWord = wordList[number.Next(0, wordList.Length)];
            arrayWordBuild.Append(string.Empty.PadLeft(guessWord.Length, '*'));
            label1.Text = arrayWordBuild.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string wordToCheck = textBox1.Text;

            arrayWordBuild.Remove(0, guessWord.Length).Append(string.Empty.PadLeft(guessWord.Length, '*'));

            if (guessWord.Contains(wordToCheck))
            {

                List<int> foundIndexes = new List<int>();
                for (int i = guessWord.IndexOf(wordToCheck); i > -1; i = guessWord.IndexOf(wordToCheck, i + 1))
                {
                    foundIndexes.Add(i);
                }
                foreach (int i in foundIndexes)
                {
                    arrayWordBuild.Remove(i, wordToCheck.Length).Insert(i, wordToCheck);
                }
            }

            label1.Text = arrayWordBuild.ToString();

            if (textBox1.Text == guessWord) MessageBox.Show("You guessed the word!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}

